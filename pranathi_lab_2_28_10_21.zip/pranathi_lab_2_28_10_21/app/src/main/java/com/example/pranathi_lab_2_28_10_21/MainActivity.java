package com.example.pranathi_lab_2_28_10_21;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        EditText num1=findViewById(R.id.num1);
        EditText num2 = findViewById(R.id.num2);
        Button bt = findViewById(R.id.addbt);
        bt.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                int a = Integer.parseInt(num1.getText().toString());
                int b = Integer.parseInt(num2.getText().toString());
                int c = a + b ;
                //TextView t1=findViewById(R.id.res);
                String s = String.valueOf(c);
                //t1.setText(s);
                Intent it = new Intent(getApplicationContext(),MainActivity2.class);
                it.putExtra("sum",s);
                startActivity(it);
            }
        });
    }
    protected void onStart(){
        super.onStart();
        Toast.makeText(getApplicationContext(), "APP STARTED", Toast.LENGTH_LONG).show();
    }
    protected void onResume(){
        super.onResume();
        Toast.makeText(getApplicationContext(), "APP RESUMED", Toast.LENGTH_SHORT).show();
    }
    protected void onStop(){
        super.onStop();
        Toast.makeText(getApplicationContext(), "APP STOPPED", Toast.LENGTH_SHORT).show();
    }
    protected void onPause(){
        super.onPause();
        Toast.makeText(getApplicationContext(), "APP PAUSED", Toast.LENGTH_SHORT).show();
    }
    protected void onDestroy(){
        super.onDestroy();
        Toast.makeText(getApplicationContext(), "APP TERMINATED", Toast.LENGTH_SHORT).show();
    }
}